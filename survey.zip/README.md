# lambda-survey
The automated survey with a response
